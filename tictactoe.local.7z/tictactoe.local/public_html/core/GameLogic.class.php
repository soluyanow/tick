<?php
class GameLogic
{



}