<?php
class Settings
{
    public function readSettings() {


    }

    public function writeSettings() {


    }
}
