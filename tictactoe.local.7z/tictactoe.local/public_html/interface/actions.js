let userSide = 1; //За кого играет пользователь
let compSide = 0; //За кого играет компьютер
let gameField = new Array(); //поле клеток

let gameOver = false; //Флаг окончания игры

let moveSide = userSide; //Кто сейчас ходит, первый всегда пользователь


window.onload = function() {
    gA = new GameActions();
    userSide = gA.setPlayerSides();
    compSide = 1 - userSide;
    moveSide = userSide;

    gameField = gA.buldGameField(3,3);

    sA = new SystemActions();
    sA.setSystemHandlers();









    console.log("user side:" + userSide);
    console.log("comp side:" + compSide);
    console.log("game fild:" + moveSide);
};

class SystemActions
{
    constructor() {
        this.cellClass = "gamecell";
    }

    setSystemHandlers() {
        $("."+this.cellClass).on("click", function () {
            var coordLine = $(this).attr("data");
            var curMove = $.parseJSON(JSON.stringify(coordLine));




            console.log($.type(curMove));
        });


    }
}

class GameActions
{
    setPlayerSides()
    {
        let max = 1;
        let min = 0;

        return Math.floor(Math.random() * (max-min + 1) + min);
    }

    buldGameField(rows, columns) {
        var arr = new Array();
        for(var i = 0; i < rows; ++i){
            arr[i] = new Array();
            for(var j = 0; j < columns; ++j){
                arr[i][j] = 0;
            }
        }
        return arr;
    }



}



class GameLogic
{
    makeAMove(cellID) {



    }



}







